<?php

define("USER", "root");
define("SERVER", "localhost");
define("BD", "tmp_ticket");
define("PASS", "");
?>